# project4 > 2023-06-29 4:15pm
https://universe.roboflow.com/medical-waste-recognition/project4-vvgs8

Provided by a Roboflow user
License: CC BY 4.0

